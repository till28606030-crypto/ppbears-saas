<?php
/**
 * Plugin Name: PPBears Checkout Link
 * Description: Generates single-use checkout links with dynamic pricing for WooCommerce. Also handles custom design add-to-cart with line-by-line order meta.
 * Version: 1.1.0
 * Author: Trae AI
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PPBears_Checkout_Link {

    const TRANSIENT_PREFIX = 'ppbears_token_';
    const TOKEN_PARAM      = 'ppbears_token';

    // Allowed origins for CORS (SaaS app domains)
    const ALLOWED_ORIGINS = array(
        'https://saas.ppbears.com',
        'https://www.ppbears.com',
        'https://ppbears.com',
        'http://localhost:5173',
        'http://localhost:3000',
    );

    public function __construct() {
        // REST API
        add_action( 'rest_api_init', array( $this, 'register_api_routes' ) );

        // CORS: Allow cross-origin requests with credentials for the /add-to-cart endpoint
        add_filter( 'rest_pre_serve_request', array( $this, 'handle_cors_headers' ), 10, 4 );

        // Frontend Token Handling
        add_action( 'template_redirect', array( $this, 'handle_checkout_token' ) );

        // Price Override (handles both token-based and design-based)
        add_action( 'woocommerce_before_calculate_totals', array( $this, 'override_cart_price' ), 10, 1 );

        // Display in Cart/Checkout (for both flows)
        add_filter( 'woocommerce_get_item_data', array( $this, 'display_cart_item_data' ), 10, 2 );

        // Override Cart Item Name
        add_filter( 'woocommerce_cart_item_name', array( $this, 'override_cart_item_name' ), 10, 3 );

        // Save to Order (for both flows)
        add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'add_order_line_item_meta' ), 10, 4 );
    }

    /**
     * Handle CORS headers for cross-origin requests from the SaaS app
     */
    public function handle_cors_headers( $served, $result, $request, $server ) {
        $route = $request->get_route();

        // Only apply to our custom endpoint
        if ( strpos( $route, '/ppbears/v1/add-to-cart' ) === false ) {
            return $served;
        }

        $origin = isset( $_SERVER['HTTP_ORIGIN'] ) ? $_SERVER['HTTP_ORIGIN'] : '';

        if ( in_array( $origin, self::ALLOWED_ORIGINS, true ) ) {
            header( 'Access-Control-Allow-Origin: ' . $origin );
            header( 'Access-Control-Allow-Credentials: true' );
            header( 'Access-Control-Allow-Methods: POST, OPTIONS' );
            header( 'Access-Control-Allow-Headers: Content-Type, X-WP-Nonce' );
        }

        // Handle preflight OPTIONS request
        if ( 'OPTIONS' === $_SERVER['REQUEST_METHOD'] ) {
            status_header( 200 );
            exit;
        }

        return $served;
    }


    /**
     * 1. Register REST API Endpoints
     */
    public function register_api_routes() {
        // Original: Token-based checkout link
        register_rest_route( 'ppbears/v1', '/checkout-link', array(
            'methods'             => 'POST',
            'callback'            => array( $this, 'generate_checkout_link' ),
            'permission_callback' => '__return_true',
        ) );

        // NEW: Design-based add-to-cart with line-by-line order options
        register_rest_route( 'ppbears/v1', '/add-to-cart', array(
            'methods'             => 'POST',
            'callback'            => array( $this, 'handle_add_to_cart' ),
            'permission_callback' => '__return_true',
        ) );
    }

    /**
     * NEW: Handle Add-to-Cart for Custom Design Products
     * Accepts: { product_id, price, design_id, options: {key: value}, phone_model }
     * Returns: { success, checkout_url }
     */
    public function handle_add_to_cart( $request ) {
        $params     = $request->get_json_params();
        $product_id = isset( $params['product_id'] ) ? intval( $params['product_id'] ) : 0;
        $price      = isset( $params['price'] ) ? floatval( $params['price'] ) : 0;
        $design_id  = isset( $params['design_id'] ) ? sanitize_text_field( $params['design_id'] ) : '';
        $options     = isset( $params['options'] ) && is_array( $params['options'] ) ? $params['options'] : array();
        $product_name = isset( $params['product_name'] ) ? sanitize_text_field( $params['product_name'] ) : '';

        if ( $product_id <= 0 ) {
            return new WP_Error( 'invalid_product', '無效的商品 ID', array( 'status' => 400 ) );
        }

        if ( ! function_exists( 'WC' ) ) {
            return new WP_Error( 'wc_not_active', 'WooCommerce 未啟用', array( 'status' => 500 ) );
        }

        // Initialize WC Session & Cart if needed
        if ( is_null( WC()->session ) ) {
            $session_class = apply_filters( 'woocommerce_session_handler', 'WC_Session_Handler' );
            WC()->session  = new $session_class();
            WC()->session->init();
        }

        if ( is_null( WC()->cart ) ) {
            wc_load_cart();
        }

        // Empty the cart first (one design at a time)
        WC()->cart->empty_cart();

        // Sanitize options: each key/value becomes a separate display line
        $sanitized_options = array();
        foreach ( $options as $key => $value ) {
            $clean_key   = sanitize_text_field( (string) $key );
            $clean_value = sanitize_text_field( (string) $value );
            if ( $clean_key !== '' ) {
                $sanitized_options[ $clean_key ] = $clean_value;
            }
        }

        // Build cart item data
        $cart_item_data = array(
            'ppbears_design'      => true,
            'ppbears_design_id'   => $design_id,
            'ppbears_price'       => $price,
            'ppbears_product_name'=> $product_name,
            'ppbears_options'     => $sanitized_options, // Array of key→value pairs
        );

        // Add to cart
        $cart_item_key = WC()->cart->add_to_cart( $product_id, 1, 0, array(), $cart_item_data );

        if ( ! $cart_item_key ) {
            return new WP_Error( 'add_to_cart_failed', '加入購物車失敗', array( 'status' => 500 ) );
        }

        // Return checkout URL
        $checkout_url = wc_get_checkout_url();

        return rest_ensure_response( array(
            'success'      => true,
            'checkout_url' => $checkout_url,
            'cart_item_key' => $cart_item_key,
        ) );
    }

    /**
     * 2. Generate Token-based Checkout Link (original)
     */
    public function generate_checkout_link( $request ) {
        // 1. Auth Check
        $secret = $request->get_header( 'X_PPBEARS_SECRET' );
        if ( ! defined( 'PPBEARS_INVOICE_SECRET' ) || ! hash_equals( PPBEARS_INVOICE_SECRET, (string) $secret ) ) {
            return new WP_Error( 'rest_forbidden', 'Invalid Secret', array( 'status' => 401 ) );
        }

        // 2. Validate Body
        $params = $request->get_json_params();
        $title  = isset( $params['title'] ) ? sanitize_text_field( $params['title'] ) : '';
        $amount = isset( $params['amount'] ) ? floatval( $params['amount'] ) : 0;
        $note   = isset( $params['note'] ) ? sanitize_textarea_field( $params['note'] ) : '';

        if ( empty( $title ) || $amount <= 0 ) {
            return new WP_Error( 'rest_invalid_param', 'Title required and amount must be > 0', array( 'status' => 400 ) );
        }

        // 3. Generate Token
        $token = bin2hex( random_bytes( 32 ) );
        $data  = array(
            'title'      => $title,
            'amount'     => $amount,
            'note'       => $note,
            'created_at' => time(),
            'expires_at' => time() + 86400,
        );

        // 4. Save Transient
        set_transient( self::TRANSIENT_PREFIX . $token, $data, 86400 );

        // 5. Return URL
        $checkout_url = add_query_arg( self::TOKEN_PARAM, $token, wc_get_checkout_url() );

        return rest_ensure_response( array(
            'checkout_url' => $checkout_url,
            'expires_in'   => 86400,
        ) );
    }

    /**
     * 3. Handle Token on Frontend (original flow)
     */
    public function handle_checkout_token() {
        if ( ! isset( $_GET[ self::TOKEN_PARAM ] ) ) {
            return;
        }

        nocache_headers();

        $token = sanitize_text_field( $_GET[ self::TOKEN_PARAM ] );
        $data  = get_transient( self::TRANSIENT_PREFIX . $token );

        if ( ! $data ) {
            wp_die( '連結已失效或過期 (Link expired or invalid)', 'Error', array( 'response' => 400 ) );
        }

        if ( ! function_exists( 'WC' ) ) {
            wp_die( 'WooCommerce not active' );
        }

        if ( is_null( WC()->session ) ) {
            $session_class = apply_filters( 'woocommerce_session_handler', 'WC_Session_Handler' );
            WC()->session  = new $session_class();
            WC()->session->init();
        }

        if ( is_null( WC()->cart ) ) {
            wc_load_cart();
        }

        // Find Carrier Product
        $product = null;
        if ( function_exists( 'wc_get_products' ) ) {
            $products = wc_get_products( array(
                'name'  => '專屬開單',
                'limit' => 1,
            ) );
            if ( ! empty( $products ) ) {
                $product = $products[0];
            }
        } else {
            $product = get_page_by_title( '專屬開單', OBJECT, 'product' );
        }

        if ( ! $product ) {
            wp_die( 'System Error: Carrier product "專屬開單" not found.' );
        }
        $product_id = $product->get_id();

        WC()->cart->empty_cart();

        $cart_item_data = array(
            'ppbears_token'  => $token,
            'ppbears_title'  => $data['title'],
            'ppbears_amount' => $data['amount'],
            'ppbears_note'   => $data['note'],
        );

        WC()->cart->add_to_cart( $product_id, 1, 0, array(), $cart_item_data );

        delete_transient( self::TRANSIENT_PREFIX . $token );

        wp_safe_redirect( wc_get_checkout_url() );
        exit;
    }

    /**
     * 4. Override Price for both flows
     */
    public function override_cart_price( $cart ) {
        if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
            return;
        }

        if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 ) {
            return;
        }

        foreach ( $cart->get_cart() as $cart_item ) {
            // Token-based flow
            if ( isset( $cart_item['ppbears_amount'] ) ) {
                $price = floatval( $cart_item['ppbears_amount'] );
                if ( $price > 0 ) {
                    $cart_item['data']->set_price( $price );
                }
            }
            // Design-based flow
            if ( isset( $cart_item['ppbears_price'] ) ) {
                $price = floatval( $cart_item['ppbears_price'] );
                if ( $price > 0 ) {
                    $cart_item['data']->set_price( $price );
                }
            }
        }
    }

    /**
     * Override Cart Item Name dynamically to "客製化商品"
     */
    public function override_cart_item_name( $name, $cart_item, $cart_item_key ) {
        if ( isset( $cart_item['ppbears_design'] ) && $cart_item['ppbears_design'] ) {
            if ( isset( $cart_item['data'] ) && is_object( $cart_item['data'] ) ) {
                $permalink = $cart_item['data']->get_permalink( $cart_item );
                return $permalink ? sprintf( '<a href="%s">%s</a>', esc_url( $permalink ), '客製化商品' ) : '客製化商品';
            }
            return '客製化商品';
        }
        return $name;
    }

    /**
     * 5. Display Meta in Cart/Checkout
     */
    public function display_cart_item_data( $item_data, $cart_item ) {
        // Token-based flow
        if ( isset( $cart_item['ppbears_title'] ) ) {
            $item_data[] = array(
                'key'   => '開單品名',
                'value' => $cart_item['ppbears_title'],
            );
        }

        // Design-based flow: show each option as a line
        if ( isset( $cart_item['ppbears_options'] ) && is_array( $cart_item['ppbears_options'] ) ) {
            // Display internal Product Name
            if ( ! empty( $cart_item['ppbears_product_name'] ) ) {
                $item_data[] = array(
                    'key'   => '商品名稱',
                    'value' => $cart_item['ppbears_product_name'],
                );
            }
            // [REMOVED] '手機型號' auto-display to prevent incorrect labels for non-phone products
            foreach ( $cart_item['ppbears_options'] as $label => $value ) {
                $item_data[] = array(
                    'key'   => $label,
                    'value' => $value,
                );
            }
        }

        return $item_data;
    }

    /**
     * 6. Save Meta to Order — each option as a SEPARATE meta line
     */
    public function add_order_line_item_meta( $item, $cart_item_key, $values, $order ) {
        // Token-based flow
        if ( isset( $values['ppbears_title'] ) ) {
            $item->add_meta_data( '開單品名', $values['ppbears_title'] );
        }
        if ( isset( $values['ppbears_amount'] ) ) {
            $item->add_meta_data( '開單金額', $values['ppbears_amount'] );
        }
        if ( ! empty( $values['ppbears_note'] ) ) {
            $item->add_meta_data( '開單備註', $values['ppbears_note'] );
        }

        // Design-based flow: each option saved as individual meta line
        if ( isset( $values['ppbears_design'] ) && $values['ppbears_design'] ) {
            // Override the actual order product name
            $item->set_name( '客製化商品' );
            
            if ( ! empty( $values['ppbears_design_id'] ) ) {
                $item->add_meta_data( '設計ID', $values['ppbears_design_id'] );
            }
            if ( ! empty( $values['ppbears_product_name'] ) ) {
                $item->add_meta_data( '商品名稱', $values['ppbears_product_name'] );
            }
            // [REMOVED] '手機型號' metadata adding
            if ( isset( $values['ppbears_options'] ) && is_array( $values['ppbears_options'] ) ) {
                foreach ( $values['ppbears_options'] as $label => $value ) {
                    // Each option becomes its own line in the WooCommerce order
                    $item->add_meta_data( (string) $label, (string) $value );
                }
            }
        }
    }
}

new PPBears_Checkout_Link();
