<?php
/**
 * Plugin Name: PPBears Checkout Link
 * Description: Generates single-use checkout links with dynamic pricing for WooCommerce. Also handles custom design add-to-cart with line-by-line order meta.
 * Version: 1.1.0
 * Author: Trae AI
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PPBears_Checkout_Link {

    const TRANSIENT_PREFIX = 'ppbears_token_';
    const TOKEN_PARAM      = 'ppbears_token';

    // Allowed origins for CORS (SaaS app domains)
    const ALLOWED_ORIGINS = array(
        'https://saas.ppbears.com',
        'https://www.ppbears.com',
        'https://ppbears.com',
        'http://localhost:5173',
        'http://localhost:3000',
    );

    public function __construct() {
        // REST API
        add_action( 'rest_api_init', array( $this, 'register_api_routes' ) );

        // CORS: Allow cross-origin requests with credentials for the /add-to-cart endpoint
        add_filter( 'rest_pre_serve_request', array( $this, 'handle_cors_headers' ), 10, 4 );

        // Frontend Token Handling
        add_action( 'template_redirect', array( $this, 'handle_checkout_token' ) );

        // Price Override (handles both token-based and design-based)
        add_action( 'woocommerce_before_calculate_totals', array( $this, 'override_cart_price' ), 10, 1 );

        // Display in Cart/Checkout (for both flows)
        add_filter( 'woocommerce_get_item_data', array( $this, 'display_cart_item_data' ), 10, 2 );

        // Override Cart Item Name
        add_filter( 'woocommerce_cart_item_name', array( $this, 'override_cart_item_name' ), 10, 3 );

        // Save to Order — Classic Checkout hook
        add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'add_order_line_item_meta' ), 10, 4 );

        // Save to Order — Block Checkout compatibility (fires after order is placed via Store API)
        add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'block_checkout_save_order_meta' ), 10, 1 );

        // Save to Order — Classic fallback: also fires after order created in classic checkout
        add_action( 'woocommerce_checkout_order_created', array( $this, 'block_checkout_save_order_meta' ), 10, 1 );
    }

    /**
     * Handle CORS headers for cross-origin requests from the SaaS app
     */
    public function handle_cors_headers( $served, $result, $request, $server ) {
        $route = $request->get_route();

        // Only apply to our custom endpoint
        if ( strpos( $route, '/ppbears/v1/add-to-cart' ) === false ) {
            return $served;
        }

        $origin = isset( $_SERVER['HTTP_ORIGIN'] ) ? $_SERVER['HTTP_ORIGIN'] : '';

        if ( in_array( $origin, self::ALLOWED_ORIGINS, true ) ) {
            header( 'Access-Control-Allow-Origin: ' . $origin );
            header( 'Access-Control-Allow-Credentials: true' );
            header( 'Access-Control-Allow-Methods: POST, OPTIONS' );
            header( 'Access-Control-Allow-Headers: Content-Type, X-WP-Nonce' );
        }

        // Handle preflight OPTIONS request
        if ( 'OPTIONS' === $_SERVER['REQUEST_METHOD'] ) {
            status_header( 200 );
            exit;
        }

        return $served;
    }


    /**
     * 1. Register REST API Endpoints
     */
    public function register_api_routes() {
        // Original: Token-based checkout link
        register_rest_route( 'ppbears/v1', '/checkout-link', array(
            'methods'             => 'POST',
            'callback'            => array( $this, 'generate_checkout_link' ),
            'permission_callback' => '__return_true',
        ) );

        // NEW: Design-based add-to-cart with line-by-line order options
        register_rest_route( 'ppbears/v1', '/add-to-cart', array(
            'methods'             => 'POST',
            'callback'            => array( $this, 'handle_add_to_cart' ),
            'permission_callback' => '__return_true',
        ) );
    }

    /**
     * NEW: Handle Add-to-Cart for Custom Design Products
     * Accepts: { product_id, price, design_id, options: {key: value}, phone_model }
     * Returns: { success, checkout_url }
     */
    public function handle_add_to_cart( $request ) {
        try {
            $params     = $request->get_json_params();
            $product_id = isset( $params['product_id'] ) ? intval( $params['product_id'] ) : 0;
            $price      = isset( $params['price'] ) ? floatval( $params['price'] ) : 0;
            $design_id  = isset( $params['design_id'] ) ? sanitize_text_field( $params['design_id'] ) : '';
            $options     = isset( $params['options'] ) && is_array( $params['options'] ) ? $params['options'] : array();
            $product_name = isset( $params['product_name'] ) ? sanitize_text_field( $params['product_name'] ) : '';

            if ( $product_id <= 0 ) {
                return new WP_Error( 'invalid_product', '無效的商品 ID', array( 'status' => 400 ) );
            }

            if ( ! function_exists( 'WC' ) || ! function_exists( 'wc_load_cart' ) ) {
                return new WP_Error( 'wc_not_active', 'WooCommerce 未啟用', array( 'status' => 500 ) );
            }

            // Safely initializing WooCommerce Cart & Session
            wc_load_cart();

            if ( is_null( WC()->cart ) ) {
                return new WP_Error( 'cart_not_ready', '購物車系統初始化失敗', array( 'status' => 500 ) );
            }

            // Remove only the cart item with the same design_id (for re-try / update).
            // Do NOT empty the entire cart — customers may have multiple designs!
            foreach ( WC()->cart->get_cart() as $cart_key => $cart_item ) {
                if ( isset( $cart_item['ppbears_design_id'] ) && $cart_item['ppbears_design_id'] === $design_id ) {
                    WC()->cart->remove_cart_item( $cart_key );
                    break;
                }
            }

            // Sanitize options: each key/value becomes a separate display line
            $sanitized_options = array();
            foreach ( $options as $key => $value ) {
                $val_str = is_array($value) ? implode(', ', $value) : (string) $value;
                $clean_key   = sanitize_text_field( (string) $key );
                $clean_value = sanitize_text_field( $val_str );
                if ( $clean_key !== '' ) {
                    $sanitized_options[ $clean_key ] = $clean_value;
                }
            }

            // Build cart item data
            $cart_item_data = array(
                'ppbears_design'      => true,
                'ppbears_design_id'   => $design_id,
                'ppbears_price'       => $price,
                'ppbears_product_name'=> $product_name,
                'ppbears_options'     => $sanitized_options, // Array format
                'ppbears_options_json'=> json_encode( $sanitized_options ), // JSON String format (more robust)
            );

            // Add to cart
            $cart_item_key = WC()->cart->add_to_cart( $product_id, 1, 0, array(), $cart_item_data );

            if ( ! $cart_item_key ) {
                $notices = wc_get_notices( 'error' );
                $error_msgs = array();
                if ( ! empty( $notices ) ) {
                    foreach ( $notices as $notice ) {
                        $error_msgs[] = is_array( $notice ) ? $notice['notice'] : wp_strip_all_tags( $notice );
                    }
                    wc_clear_notices();
                }
                $reason = empty( $error_msgs ) ? '可能商品已停售或缺貨' : implode( ' | ', $error_msgs );
                
                // Return 400 so the frontend sees it as a business logic error, not a server crash!
                return new WP_Error( 'add_to_cart_failed', $reason, array( 'status' => 400 ) );
            }

            // Return checkout URL
            $checkout_url = wc_get_checkout_url();

            return rest_ensure_response( array(
                'success'      => true,
                'checkout_url' => $checkout_url,
                'cart_item_key' => $cart_item_key,
            ) );
            
        } catch ( \Exception $e ) {
            return new WP_Error( 'cart_exception', '加入購物車發生例外: ' . $e->getMessage(), array( 'status' => 500 ) );
        } catch ( \Throwable $e ) {
            return new WP_Error( 'cart_fatal', '伺服器嚴重錯誤: ' . $e->getMessage(), array( 'status' => 500 ) );
        }
    }

    /**
     * 2. Generate Token-based Checkout Link (original)
     */
    public function generate_checkout_link( $request ) {
        // 1. Auth Check
        $secret = $request->get_header( 'X_PPBEARS_SECRET' );
        if ( ! defined( 'PPBEARS_INVOICE_SECRET' ) || ! hash_equals( PPBEARS_INVOICE_SECRET, (string) $secret ) ) {
            return new WP_Error( 'rest_forbidden', 'Invalid Secret', array( 'status' => 401 ) );
        }

        // 2. Validate Body
        $params = $request->get_json_params();
        $title  = isset( $params['title'] ) ? sanitize_text_field( $params['title'] ) : '';
        $amount = isset( $params['amount'] ) ? floatval( $params['amount'] ) : 0;
        $note   = isset( $params['note'] ) ? sanitize_textarea_field( $params['note'] ) : '';

        if ( empty( $title ) || $amount <= 0 ) {
            return new WP_Error( 'rest_invalid_param', 'Title required and amount must be > 0', array( 'status' => 400 ) );
        }

        // 3. Generate Token
        $token = bin2hex( random_bytes( 32 ) );
        $data  = array(
            'title'      => $title,
            'amount'     => $amount,
            'note'       => $note,
            'created_at' => time(),
            'expires_at' => time() + 86400,
        );

        // 4. Save Transient
        set_transient( self::TRANSIENT_PREFIX . $token, $data, 86400 );

        // 5. Return URL
        $checkout_url = add_query_arg( self::TOKEN_PARAM, $token, wc_get_checkout_url() );

        return rest_ensure_response( array(
            'checkout_url' => $checkout_url,
            'expires_in'   => 86400,
        ) );
    }

    /**
     * 3. Handle Token on Frontend (original flow)
     */
    public function handle_checkout_token() {
        if ( ! isset( $_GET[ self::TOKEN_PARAM ] ) ) {
            return;
        }

        nocache_headers();

        $token = sanitize_text_field( $_GET[ self::TOKEN_PARAM ] );
        $data  = get_transient( self::TRANSIENT_PREFIX . $token );

        if ( ! $data ) {
            wp_die( '連結已失效或過期 (Link expired or invalid)', 'Error', array( 'response' => 400 ) );
        }

        if ( ! function_exists( 'WC' ) ) {
            wp_die( 'WooCommerce not active' );
        }

        if ( is_null( WC()->session ) ) {
            $session_class = apply_filters( 'woocommerce_session_handler', 'WC_Session_Handler' );
            WC()->session  = new $session_class();
            WC()->session->init();
        }

        if ( is_null( WC()->cart ) ) {
            wc_load_cart();
        }

        // Find Carrier Product
        $product = null;
        if ( function_exists( 'wc_get_products' ) ) {
            $products = wc_get_products( array(
                'name'  => '專屬開單',
                'limit' => 1,
            ) );
            if ( ! empty( $products ) ) {
                $product = $products[0];
            }
        } else {
            $product = get_page_by_title( '專屬開單', OBJECT, 'product' );
        }

        if ( ! $product ) {
            wp_die( 'System Error: Carrier product "專屬開單" not found.' );
        }
        $product_id = $product->get_id();

        WC()->cart->empty_cart();

        $cart_item_data = array(
            'ppbears_token'  => $token,
            'ppbears_title'  => $data['title'],
            'ppbears_amount' => $data['amount'],
            'ppbears_note'   => $data['note'],
        );

        WC()->cart->add_to_cart( $product_id, 1, 0, array(), $cart_item_data );

        delete_transient( self::TRANSIENT_PREFIX . $token );

        wp_safe_redirect( wc_get_checkout_url() );
        exit;
    }

    /**
     * 4. Override Price for both flows
     */
    public function override_cart_price( $cart ) {
        if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
            return;
        }

        if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 ) {
            return;
        }

        foreach ( $cart->get_cart() as $cart_item ) {
            // Token-based flow
            if ( isset( $cart_item['ppbears_amount'] ) ) {
                $price = floatval( $cart_item['ppbears_amount'] );
                if ( $price > 0 ) {
                    $cart_item['data']->set_price( $price );
                }
            }
            // Design-based flow
            if ( isset( $cart_item['ppbears_price'] ) ) {
                $price = floatval( $cart_item['ppbears_price'] );
                if ( $price > 0 ) {
                    $cart_item['data']->set_price( $price );
                }
            }
        }
    }

    /**
     * Override Cart Item Name dynamically to "客製化商品"
     */
    public function override_cart_item_name( $name, $cart_item, $cart_item_key ) {
        if ( isset( $cart_item['ppbears_design'] ) && $cart_item['ppbears_design'] ) {
            if ( isset( $cart_item['data'] ) && is_object( $cart_item['data'] ) ) {
                $permalink = $cart_item['data']->get_permalink( $cart_item );
                return $permalink ? sprintf( '<a href="%s">%s</a>', esc_url( $permalink ), '客製化商品' ) : '客製化商品';
            }
            return '客製化商品';
        }
        return $name;
    }

    /**
     * 5. Display Meta in Cart/Checkout
     */
    public function display_cart_item_data( $item_data, $cart_item ) {
        // Token-based flow
        if ( isset( $cart_item['ppbears_title'] ) ) {
            $item_data[] = array(
                'key'   => '開單品名',
                'value' => $cart_item['ppbears_title'],
            );
        }

        // Design-based flow: show each option as a line
        if ( isset( $cart_item['ppbears_design'] ) && $cart_item['ppbears_design'] ) {
            // Display internal Product Name
            if ( ! empty( $cart_item['ppbears_product_name'] ) ) {
                $item_data[] = array(
                    'key'   => '商品名稱',
                    'value' => $cart_item['ppbears_product_name'],
                );
            }

            // Get options (either from array or JSON string)
            $options = array();
            if ( isset( $cart_item['ppbears_options'] ) && is_array( $cart_item['ppbears_options'] ) && ! empty( $cart_item['ppbears_options'] ) ) {
                $options = $cart_item['ppbears_options'];
            } elseif ( isset( $cart_item['ppbears_options_json'] ) && ! empty( $cart_item['ppbears_options_json'] ) ) {
                $options = json_decode( $cart_item['ppbears_options_json'], true );
            }

            if ( is_array( $options ) ) {
                foreach ( $options as $label => $value ) {
                    $item_data[] = array(
                        'key'   => $label,
                        'value' => $value,
                    );
                }
            }
        }

        return $item_data;
    }

    /**
     * 6. Save Meta to Order — each option as a SEPARATE meta line (Classic Checkout)
     */
    public function add_order_line_item_meta( $item, $cart_item_key, $values, $order ) {
        // Token-based flow
        if ( isset( $values['ppbears_title'] ) ) {
            $item->add_meta_data( '開單品名', $values['ppbears_title'] );
        }
        if ( isset( $values['ppbears_amount'] ) ) {
            $item->add_meta_data( '開單金額', $values['ppbears_amount'] );
        }
        if ( ! empty( $values['ppbears_note'] ) ) {
            $item->add_meta_data( '開單備註', $values['ppbears_note'] );
        }

        // Design-based flow: each option saved as individual meta line
        if ( isset( $values['ppbears_design'] ) && $values['ppbears_design'] ) {
            // Override the actual order product name
            $item->set_name( '客製化商品' );

            if ( ! empty( $values['ppbears_design_id'] ) ) {
                $item->add_meta_data( '設計ID', $values['ppbears_design_id'] );
            }
            if ( ! empty( $values['ppbears_product_name'] ) ) {
                $item->add_meta_data( '商品名稱', $values['ppbears_product_name'] );
            }

            // Get options (either from array or JSON string)
            $options = array();
            if ( isset( $values['ppbears_options'] ) && is_array( $values['ppbears_options'] ) && ! empty( $values['ppbears_options'] ) ) {
                $options = $values['ppbears_options'];
            } elseif ( isset( $values['ppbears_options_json'] ) && ! empty( $values['ppbears_options_json'] ) ) {
                $options = json_decode( $values['ppbears_options_json'], true );
            }

            if ( is_array( $options ) ) {
                foreach ( $options as $label => $value ) {
                    $item->add_meta_data( (string) $label, (string) $value );
                }
            }
        }
    }

    /**
     * 7. Block Checkout Compatibility — Save specs to order AFTER order is created
     * Fires via: woocommerce_store_api_checkout_order_processed (Block Checkout)
     *        and: woocommerce_checkout_order_created (Classic fallback)
     * Iterates all line items in the new order, finds ppbears items via cart session,
     * and writes specs as order line item meta if not already written.
     */
    public function block_checkout_save_order_meta( $order ) {
        if ( ! $order instanceof WC_Order ) {
            return;
        }

        // Get cart contents from WC session to match items
        $cart_contents = WC()->cart ? WC()->cart->get_cart() : array();

        foreach ( $order->get_items() as $item_id => $item ) {
            // Skip if we already saved the specs (design ID already written by classic hook)
            $existing_design_id = $item->get_meta( '設計ID', true );

            // Find matching cart item
            $matched_cart_item = null;
            foreach ( $cart_contents as $cart_key => $cart_item ) {
                if (
                    isset( $cart_item['ppbears_design'] ) &&
                    isset( $cart_item['ppbears_design_id'] ) &&
                    ( empty( $existing_design_id ) || $existing_design_id === $cart_item['ppbears_design_id'] )
                ) {
                    $matched_cart_item = $cart_item;
                    break;
                }
            }

            if ( ! $matched_cart_item ) {
                continue;
            }

            // Only write if design ID meta is missing (avoid duplicates from classic hook)
            if ( empty( $existing_design_id ) ) {
                $item->set_name( '客製化商品' );

                if ( ! empty( $matched_cart_item['ppbears_design_id'] ) ) {
                    $item->add_meta_data( '設計ID', $matched_cart_item['ppbears_design_id'] );
                }
                if ( ! empty( $matched_cart_item['ppbears_product_name'] ) ) {
                    $item->add_meta_data( '商品名稱', $matched_cart_item['ppbears_product_name'] );
                }

                // Get options (either from array or JSON string)
                $options = array();
                if ( isset( $matched_cart_item['ppbears_options'] ) && is_array( $matched_cart_item['ppbears_options'] ) && ! empty( $matched_cart_item['ppbears_options'] ) ) {
                    $options = $matched_cart_item['ppbears_options'];
                } elseif ( isset( $matched_cart_item['ppbears_options_json'] ) && ! empty( $matched_cart_item['ppbears_options_json'] ) ) {
                    $options = json_decode( $matched_cart_item['ppbears_options_json'], true );
                }

                if ( is_array( $options ) ) {
                    foreach ( $options as $label => $value ) {
                        $item->add_meta_data( (string) $label, (string) $value );
                    }
                }

                $item->save();
            }
        }
    }
}

new PPBears_Checkout_Link();
